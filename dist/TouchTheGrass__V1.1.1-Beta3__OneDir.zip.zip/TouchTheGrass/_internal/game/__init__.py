# game/__init__.py
from .game import run_game
